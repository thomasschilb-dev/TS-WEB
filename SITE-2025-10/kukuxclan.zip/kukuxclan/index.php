<!DOCTYPE html>
<html>
<head>
<link rel="icon" type="image/png" href="favicon.png">
<title>Ku Kux Clan | KKC</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="language" content="en-us">
<meta name="author" content="Thomas Schilb">
<meta name="publisher" content="Thomas Schilb">
<meta name="copyright" content="(c)2017-2024">
<meta name="description" content="Clan Site">
<meta name="keywords" content="anonymous, ccc, hitler, illuminati, kkk, kkc, kukuxclan, uno">
<meta name="page-topic" content="Kukuxclan | KKC">
<meta name="page-type" content="Private Homepage">
<meta name="audience" content="all">
<meta name="robots" content="index, follow"> 
<meta name="googlebot" content="index, follow"> 
<meta name="pagerank" content="10"> 
<meta name="msnbot" content="index,follow"> 
<meta name="revisit" content="2 Days"> 
<meta name="revisit-after" content="2 Days"> 
<meta name="alexa" content="100">
<style type="text/css">
.center {
margin: 0;
background: black;
position: absolute;
top: 50%;
left: 50%;
margin-right: -50%;
transform: translate(-50%, -50%)
}
.auto-style1 {
border-color: #000000;
border-width: 0;
margin: 0;
background: black;
position: absolute;
top: 50%;
left: 50%;
margin-right: -50%;
transform: translate(-50%, -50%)
}
#gray2color:hover {
-webkit-filter: grayscale(0%);
-webkit-transition: .5s ease-in-out;
-moz-filter: grayscale(0%);
-moz-transition: .5s ease-in-out;
-o-filter: grayscale(0%);
-o-transition: .5s ease-in-out;
}
#gray2color {
-webkit-filter: grayscale(100%);
-webkit-transition: .5s ease-in-out;
-moz-filter: grayscale(100%);
-moz-transition: .5s ease-in-out;
-o-filter: grayscale(100%);
-o-transition: .5s ease-in-out;
}

.auto-style3 {
	border-width: 0px;
}

.auto-style4 {
	background: black;
	position: absolute;
	top: 50%;
	left: 50%;
	margin-right: -50%;
	transform: translate(-50%, -50%);
	text-align: center;
	margin-left: 0;
	margin-top: 0;
	margin-bottom: 0;
}

.auto-style5 {
	font-family: "Courier New", Courier, monospace;
	color: #FFFFFF;
}

a {
	color: #808080;
}
a:visited {
	color: #808080;
}
a:active {
	color: #808080;
}
a:hover {
	color: #FF0000;
}

</style>
<base target="_self">
</head>

<body style="color: #808080; background-color: #000000">
<table cellpadding="0" cellspacing="0" class="auto-style1">
	<tr>
	<td class="auto-style4">
		<a href="site.php" target="_self" title="Ready?">
		<img src="img/kukuxclan-gate.png" class="auto-style3"></a><br><br>
		<span class="auto-style5">Messeturm, Frankfurt, Germany<br>&gt;
		<a href="https://www.messefrankfurt.com/webcam/c003big.jpg" target="_blank">
		Webcam</a> &lt;<br><br>No. <?php include('no.php'); ?></span></td>
		
	</tr>
		
</table>
