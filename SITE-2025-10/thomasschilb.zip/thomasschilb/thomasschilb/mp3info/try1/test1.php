<?php
use wapmorgan\Mp3Info\Mp3Info;
// To get basic audio information
$audio = new Mp3Info('./audio.mp3');
echo $audio;
?>
