
<head>
<style type="text/css">
.auto-style1 {
	text-align: center;
}
.auto-style2 {
	font-size: xx-small;
}
</style>
<meta content="TS-INDEXER" name="keywords">
<meta content="TS-INDEXER" name="description">
</head>

<title>TS-INDEXER</title>
<base target="_blank">

<form action="http://www.google.com/search" method="get" target="_blank">
    <div class="auto-style1">
		<br>TS-INDEXER<br><br>
    <input type="text" name="q" alt="search">
    <input type="hidden" name="q" value="-AIzaSyDemOtbU3bL0ElsGehevrHD2sNOBjsqB6c -inurl:(htm|html|php|pls|txt) intitle:index.of ">
    <input type="submit" value="Search">
<br><br>Powered by Google<br><br><span class="auto-style2">v0.0.0.3</span></div>
</form>