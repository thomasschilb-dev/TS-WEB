<form method="get" action="http://www.google.com/search">
    <input type="text" name="q" placeholder="Search">
    <input type="submit" value="Google Search" class="sprite-search">
    <input type="checkbox"  name="sitesearch" value="samplesite.com" checked >
</form>