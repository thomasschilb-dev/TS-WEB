<html>
<title>MD5 - Hashtag Generator 1.0</title>
<body>
<form action="md5.php" method="POST">
MD5 - Hashtag Generator 1.0<br><br>
Input: <input type="text" name="input"><br><br>
<input type="submit" target="_self"><br><br>
</form>
</body>
</html>
<?php
$str = $_POST["input"];
echo 'MD5: '.md5($str);
?>